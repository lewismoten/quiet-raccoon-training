
1.0.0 / 2014-05-05
==================

 * add negative support. fixes #6

0.3.0 / 2014-03-19
==================

 * added terabyte support

0.2.1 / 2013-04-01 
==================

  * add .component

0.2.0 / 2012-10-28 
==================

  * bytes(200).should.eql('200b')

0.1.0 / 2012-07-04 
==================

  * add bytes to string conversion [yields]
