module.exports = require('./lib/clean');
