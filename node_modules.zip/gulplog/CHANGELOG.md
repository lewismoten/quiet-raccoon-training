# gulplog changelog

## 1.0.0

- Initial release
- No implementation changed since initial commit

## 0.0.0

- Experimentation
